package Main_Functionlaties;

import org.testng.annotations.Test;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class ParaBank_AdminPage 

{
	WebDriver driver;
	@BeforeTest
	public void beforeTest() throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		driver=new ChromeDriver(); 

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		Thread.sleep(2000);
		driver.get("https://parabank.parasoft.com/parabank/index.htm");
	}
	@Test
	public void AdminPage() throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"headerPanel\"]/ul[1]/li[6]/a")).click();

		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Initialize']")).click();

		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[normalize-space()='Clean']")).click();

		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"accessMode3\"]")).click();

		Thread.sleep(2000);
		WebElement l = driver.findElement(By.xpath("//*[@id=\"soapEndpoint\"]"));
		l.clear();
		l.sendKeys("ABC");

		Thread.sleep(2000);
		WebElement l1 = driver.findElement(By.xpath("//*[@id=\"restEndpoint\"]"));
		l1.sendKeys("DEF");

		Thread.sleep(2000);
		WebElement l2 =driver.findElement(By.xpath("//*[@id=\"endpoint\"]"));
		l2.clear();
		l2.sendKeys("GHI77");

		Thread.sleep(2000);
		WebElement l3 = driver.findElement(By.xpath("//*[@id=\"initialBalance\"]"));
		l3.clear();
		l3.sendKeys("6700");

		Thread.sleep(2000);
		WebElement l4 = driver.findElement(By.xpath("//*[@id=\"minimumBalance\"]"));
		l4.clear();
		l4.sendKeys("67");

		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,500)");

		Thread.sleep(2000);
		Select s1=new Select(driver.findElement(By.xpath("//*[@id=\"loanProvider\"]")));
		s1.selectByValue("jms");

		Thread.sleep(2000);
		Select s=new Select(driver.findElement(By.xpath("//*[@id=\"loanProcessor\"]")));
		s.selectByValue("down");

		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"loanProcessorThreshold\"]")).sendKeys("13");

		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"adminForm\"]/input")).click();

		Thread.sleep(2000);
	}

	@AfterTest
	public void afterTest()
	{
		driver.close();
	}

}
