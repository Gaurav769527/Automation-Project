package Main_Functionlaties;

import org.testng.annotations.Test;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class ParaBank_Products {

	WebDriver driver;
	@BeforeTest
	public void beforeTest() throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		driver=new ChromeDriver(); 

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		Thread.sleep(2000);
		driver.get("https://parabank.parasoft.com/parabank/index.htm");
		Thread.sleep(3000);
	}

	@Test 
	public void Products () throws Exception
	{
		driver.findElement(By.xpath("//*[@id=\"headerPanel\"]/ul[1]/li[4]/a")).click();
		Thread.sleep(1500);


		JavascriptExecutor js=(JavascriptExecutor)driver;

		js.executeScript("window.scrollBy(0,400)");

		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id=\"hs-eu-confirmation-button\"]")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//h4[@id='heading-1']")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"collapse-1\"]/li[7]")).click();


		Thread.sleep(1000);

		driver.findElement(By.xpath("//h4[@id='heading-1']")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//h4[@id='heading-2']")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//label[@for='sf-input-8df55b2415f7ce6ee958798e959aa35f']")).click();

		Thread.sleep(1000);

		driver.findElement(By.xpath("//h4[@id='heading-2']")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@name='_sf_submit']")).submit();

		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,700)");

		Thread.sleep(3000);

		driver.findElement(By.linkText("Request Demo")).click();

		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,200)");

		Thread.sleep(1000);

		driver.findElement(By.xpath("//input[@id='email-7ed713b5-8852-4410-8832-fb8a72b5ef5a']")).sendKeys("abc@edubridge.com");

		Thread.sleep(1000);

		driver.findElement(By.xpath("//input[@id='firstname-7ed713b5-8852-4410-8832-fb8a72b5ef5a']")).sendKeys("Tara");

		Thread.sleep(1000);

		driver.findElement(By.xpath("//input[@id='lastname-7ed713b5-8852-4410-8832-fb8a72b5ef5a']")).sendKeys("Singh");

		Thread.sleep(1000);

		driver.findElement(By.xpath("//input[@id='company-7ed713b5-8852-4410-8832-fb8a72b5ef5a']")).sendKeys("EduBridge");

		Thread.sleep(1000);

		driver.findElement(By.xpath("//input[@id='jobtitle-7ed713b5-8852-4410-8832-fb8a72b5ef5a']")).sendKeys("Trainer");

		Thread.sleep(1000);

		driver.findElement(By.xpath("//input[@id='phone-7ed713b5-8852-4410-8832-fb8a72b5ef5a']")).sendKeys("8968122321");

		Thread.sleep(1500);

		Select s=new Select(driver.findElement(By.xpath("//select[@name='country']")));
		s.selectByValue("India");	

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@value='REQUEST DEMO']")).submit();	
	}


	@AfterTest
	public void afterTest()
	{
		driver.close();
	}


}
