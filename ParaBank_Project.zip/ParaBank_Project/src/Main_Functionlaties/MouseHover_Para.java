package Main_Functionlaties;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import pom_Para.ParaBank;

public class MouseHover_Para {

	public static void main(String[] args) throws Exception
	{

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		ParaBank p=new ParaBank();

		p.maximizeBroswer(driver);
		p.url(driver);

		driver.findElement(By.xpath("//*[@id=\"headerPanel\"]/ul[1]/li[5]/a")).click();


		Thread.sleep(3000);
		Actions a=new Actions(driver);

		List<WebElement>ls=driver.findElements(By.xpath("//*[@id=\"menu-header-menu\"]"));


		int size=ls.size();
		System.out.println("No of Webelements: " +size);


		for (int i=1; i<=size; i++)
		{

			Thread.sleep(3000);

			System.out.println(driver.findElement(By.xpath("//*[@id=\"menu-header-menu\"]["+i+"]")).getText());


			a.moveToElement(driver.findElement(By.xpath("//*[@id=\"menu-header-menu\"]/li[3]/a"))).perform();

			Thread.sleep(2000);
			driver.findElement(By.xpath("//a[@title='Parasoft dotTEST']")).click();

			Thread.sleep(2000);
			p.closeBroswer(driver);
		}

	}
}
