package Basic_Program;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class URL_Validator_Para {

	public static void main(String[] args) throws Exception
	{
	
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		driver.manage().window().maximize();

		driver.get("https://parabank.parasoft.com/parabank/index.htm");

		Thread.sleep(2000);
		
		String acceptedURL="https://parabank.parasoft.com/parabank/index.htm";
		String actualUrl =driver.getCurrentUrl();
	

		if(actualUrl.equals(acceptedURL))
		{
			System.out.println("URL is Valid");
		}
		else
		{
			System.out.println("URL is not Valid");
		}

	}

}
