package Basic_Program;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dialog_Para {

	public static void main(String[] args) throws Exception
	{

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.get("https://parabank.parasoft.com/parabank/index.htm");

		Thread.sleep(2000);

		String username=JOptionPane.showInputDialog("Enter UserName");
		driver.findElement(By.xpath("//*[@id=\"loginPanel\"]/form/div[1]/input")).sendKeys(username);

		Thread.sleep(2000);
		String pwd=JOptionPane.showInputDialog("Enter Password");
		driver.findElement(By.xpath("//*[@id=\"loginPanel\"]/form/div[2]/input")).sendKeys(pwd);

		Thread.sleep(2000);

		driver.findElement(By.xpath ("//*[@id=\"loginPanel\"]/form/div[3]/input")).click();

		Thread.sleep(3000);

		driver.findElement(By.xpath ("//*[@id=\"leftPanel\"]/ul/li[8]/a")).click();

		Thread.sleep(2000);


		driver.close();

	}

}
