package Basic_Program;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CrossBrowser_Para {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter 1 for Google Chrome.\n Enter 2 for Mozilla Firefox");;
		int input=s.nextInt();
		WebDriver driver=null;

		switch (input)
		{
		case 1:
			System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\HP\\\\Desktop\\\\EDU-Data\\\\Automation Testing\\\\BrowserExtension\\\\chromedriver.exe");
			driver=new ChromeDriver ();
			break;

		case 2:
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\geckoDriver.exe");

			driver=new FirefoxDriver();

			break;

		default:System.out.println("Invalid input");
		}
		driver.get("https://parabank.parasoft.com/parabank/index.htm");

		s.close();

	}

}
