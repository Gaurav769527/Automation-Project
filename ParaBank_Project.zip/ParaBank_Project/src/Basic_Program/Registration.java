package Basic_Program;

import java.util.Scanner;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Registration {

	public static void main(String[] args) throws Exception 
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter FirstName: ");
		String FirstName=s.next();
		System.out.println("Enter LastName: ");
		String LastName=s.next();
		System.out.println("Enter Address: ");
		String Address=s.next();
		System.out.println("Enter City");
		String City=s.next();
		System.out.println("Enter State");
		String State=s.next();
		System.out.println("Enter ZipCode");
		String ZipCode=s.next();
		System.out.println("Phone");
		String Phone=s.next();
		System.out.println("SSN");
		String SSN=s.next();
		System.out.println("Enter Username");
		String Username=s.next();
		System.out.println("Enter Password");
		String Password=s.next();
		System.out.println("Confirm Password");
		String ConfirmPassword=s.next();

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		Thread.sleep(2000);
		driver.get("https://parabank.parasoft.com/parabank/index.htm");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"loginPanel\"]/p[2]/a")).click();

		Thread.sleep(1500);
		JavascriptExecutor js=(JavascriptExecutor)driver;

		Thread.sleep(1500);
		js.executeScript("window.scrollBy(0,500)");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"customer.firstName\"]")).sendKeys(FirstName);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"customer.lastName\"]")).sendKeys(LastName);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"customer.address.street\"]")).sendKeys(Address);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"customer.address.city\"]")).sendKeys(City);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"customer.address.state\"]")).sendKeys(State);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"customer.address.zipCode\"]")).sendKeys(ZipCode);
		
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"customer.phoneNumber\"]")).sendKeys(Phone);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"customer.ssn\"]")).sendKeys(SSN);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"customer.username\"]")).sendKeys(Username);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"customer.password\"]")).sendKeys(Password);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"repeatedPassword\"]")).sendKeys(ConfirmPassword);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"customerForm\"]/table/tbody/tr[13]/td[2]/input")).submit();
		
		Thread.sleep(2000);
		s.close();


	}

}
