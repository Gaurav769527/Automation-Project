package Basic_Program;

import java.util.Scanner;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Logout_UsingScanner {

	public static void main(String[] args) throws Exception
	{


		Scanner s=new Scanner(System.in);

		System.out.println("Enter UserName");
		String username=s.next();
		System.out.println("Enter Password");
		String password=s.next();

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		Thread.sleep(2000);
		driver.get("https://parabank.parasoft.com/parabank/index.htm");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"loginPanel\"]/form/div[1]/input")).sendKeys(username);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"loginPanel\"]/form/div[2]/input")).sendKeys(password);

		Thread.sleep(2000);
		driver.findElement(By.xpath ("//*[@id=\"loginPanel\"]/form/div[3]/input")).click();

		Thread.sleep(2000);
		driver.findElement(By.xpath ("//*[@id=\"leftPanel\"]/ul/li[8]/a")).click();

		Thread.sleep(2000);
		driver.close();

		s.close();

	}

}
