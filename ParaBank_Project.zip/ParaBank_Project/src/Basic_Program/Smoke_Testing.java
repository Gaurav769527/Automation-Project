package Basic_Program;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import pom_Para.ParaBank;

public class Smoke_Testing {

	public static void main(String[] args) throws Exception
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		Thread.sleep(2000);
		driver.get("https://parabank.parasoft.com/parabank/index.htm");
		
		ParaBank p=new ParaBank();
		
		p.enterUsername(driver, "GS382");
		
		Thread.sleep(2000);
		
		p.enterPassword(driver, "admin321");
		
		Thread.sleep(2000);
		
		p.clickOnLoginButton(driver);
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id='leftPanel']/ul/li[1]/a")).click();
		
		Thread.sleep(1500);

		Select s1=new Select(driver.findElement(By.xpath("//select[@id='type']")));
		s1.selectByValue("1");
		
		Thread.sleep(1500);

		Select s2=new Select(driver.findElement(By.xpath("//select[@id='fromAccountId']")));
		s2.selectByValue("19893");
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/div/div/form/div/input")).click();
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"newAccountId\"]")).click();
		
		

	}

}
