package DDT_Framework;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pom_Para.ParaBank;



public class paraBank_DDT {

	public static void main(String[] args) throws Exception
	{
		

		FileInputStream file = new FileInputStream("./ParaBank_DataDriven.xlsx");


		XSSFWorkbook w=new XSSFWorkbook (file);


		XSSFSheet s= w.getSheet("DataDriven");


		int rowsize=s.getLastRowNum();

		System.out.println("No of credential: "+ rowsize);


		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver(); 

	
		ParaBank pb = new ParaBank();

		
		for (int i=1; i<=rowsize; i++)
		{

			String usn = s.getRow(i).getCell(0).getStringCellValue();
			String password = s.getRow(i).getCell(1).getStringCellValue();
			System.out.println(usn +"\t\t"+ password);


			try
			{
				pb.url(driver);
				Thread.sleep(2000);
				pb.maximizeBroswer(driver);
				Thread.sleep(2000);
				pb.enterUsername(driver, usn);
				Thread.sleep(2000);
				pb.enterPassword(driver, password);
				Thread.sleep(2000);
				pb.clickOnLoginButton(driver);
				Thread.sleep(2000);
				pb.clickOnLogoutButton(driver);
				Thread.sleep(3000);


				System.out.println("valid Credential.");
				s.getRow(i).createCell(2).setCellValue("valid Credential.");

			}
			catch (Exception e)
			{

				System.out.println("Invalid Credential.");
				s.getRow(i).createCell(2).setCellValue("Invalid Credential.");
			}


		}


		FileOutputStream out = new FileOutputStream("./ParaBank_DataDriven.xlsx");
		w.write(out);

		driver.close();
		w.close();

	}

}
