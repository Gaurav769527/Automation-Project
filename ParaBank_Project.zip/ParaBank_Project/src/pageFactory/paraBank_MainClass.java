package pageFactory;

import org.openqa.selenium.WebDriver;




import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class paraBank_MainClass {
  @Test
  public void loginLogout() throws Exception
  {
	  WebDriverManager.chromedriver().setup();
	  
	  WebDriver driver= new ChromeDriver();
	  
	  driver.manage().window().maximize();
	  driver.manage().deleteAllCookies();
	  

		driver.get("https://parabank.parasoft.com/parabank/index.htm");
	  
	  paraBank_BaseClass pb= PageFactory.initElements(driver, paraBank_BaseClass.class);
	  
	  Thread.sleep(2000);
	  pb.login("asd","dsa123");
	  
	  Thread.sleep(2000);
	  driver.close();
  }
}
