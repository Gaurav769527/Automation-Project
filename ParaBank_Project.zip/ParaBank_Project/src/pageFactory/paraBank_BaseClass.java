package pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class paraBank_BaseClass {

	
	@FindBy(xpath="//*[@id=\"loginPanel\"]/form/div[1]/input")
	WebElement Username;
	
	@FindBy(xpath="//*[@id=\"loginPanel\"]/form/div[2]/input")
	WebElement Password;
	
	@FindBy(xpath="//*[@id=\"loginPanel\"]/form/div[3]/input")
	WebElement LoginButton;
	
	public void login(String usn, String pwd)
	{
		Username.sendKeys(usn);
		Password.sendKeys(pwd);
		LoginButton.submit();
	}
}
