package pom_Para;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class MainClass_Para {

	public static void main(String[] args)  throws Exception
	{

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		ParaBank p=new ParaBank();

		p.maximizeBroswer(driver);
		p.url(driver);

		Thread.sleep(2000);
		p.enterUsername(driver, "asd");
		p.enterPassword(driver, "dsa123");

		Thread.sleep(2000);
		p.clickOnLoginButton(driver);

		Thread.sleep(2000);
		p.clickOnLogoutButton(driver);

		Thread.sleep(2000);
		p.closeBroswer(driver);

	}

}
