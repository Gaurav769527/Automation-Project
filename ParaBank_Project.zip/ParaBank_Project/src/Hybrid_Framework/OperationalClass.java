package Hybrid_Framework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OperationalClass {
	
	
	public void maximizeBroswer(WebDriver driver)
	{
		driver.manage().window().maximize();
	}

	public void url(WebDriver driver)
	{
		driver.get("https://parabank.parasoft.com/parabank/index.htm");
	}

	public void enterUsername(WebDriver driver, String usn)
	{
		driver.findElement(By.name("username")).sendKeys(usn);
	}

	public void  enterPassword(WebDriver driver, String pwd)
	{
		driver.findElement(By.name("password")).sendKeys(pwd);
	}

	public void clickOnLoginButton(WebDriver driver)
	{
		driver.findElement(By.xpath ("//*[@id=\"loginPanel\"]/form/div[3]/input")).click();
	}
	
	public void clickOnLogoutButton(WebDriver driver)
	{
		driver.findElement(By.xpath ("//*[@id=\"leftPanel\"]/ul/li[8]/a")).click();
	}
	
	public void closeBroswer(WebDriver driver)
	{
		driver.close();
	}

}
