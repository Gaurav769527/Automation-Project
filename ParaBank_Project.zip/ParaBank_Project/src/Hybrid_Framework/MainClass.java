package Hybrid_Framework;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;


import io.github.bonigarcia.wdm.WebDriverManager;

public class MainClass {
	  @Test (description = "Hybrid On ParaBank")
	  public void hybrid() throws Exception
	  {
		  WebDriverManager.chromedriver();
			WebDriver driver=new ChromeDriver();

			Thread.sleep(2000);
			ReadExcelClass r=new ReadExcelClass();
			r.readExcel(driver);
}
}