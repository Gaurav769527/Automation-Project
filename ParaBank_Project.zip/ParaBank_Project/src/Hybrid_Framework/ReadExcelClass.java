package Hybrid_Framework;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

public class ReadExcelClass {
	
	public void readExcel(WebDriver driver) throws Exception
{

	
	FileInputStream file = new FileInputStream("./ParaBank_DataDriven.xlsx");

	
	XSSFWorkbook w=new XSSFWorkbook (file);


	XSSFSheet s= w.getSheet("Hybrid");

	
	int rowsize=s.getLastRowNum();

	System.out.println("No of credential: "+ rowsize);
	
	OperationalClass o= new OperationalClass();


	for (int i=1; i<=rowsize; i++)
	{
		
		String username = s.getRow(i).getCell(1).getStringCellValue();
		String password = s.getRow(i).getCell(2).getStringCellValue();
		System.out.println(username +"\t\t"+ password);
		
		try
		{

	for (int j=1; j<=rowsize; j++)
	{
		String key = s.getRow(j).getCell(0).getStringCellValue();
		if (key.equals("Maximize Browser"))
		{
			o.maximizeBroswer(driver);
			Thread.sleep(2000);
		}
		else if (key.equals("URL"))
		{
			o.url(driver);
			Thread.sleep(2000);
		}
		else if (key.equals("Username"))
		{
			o.enterUsername(driver, username);
			Thread.sleep(2000);
		}
		else if (key.equals("Password"))
		{
			o.enterPassword(driver, password);
			Thread.sleep(2000);
		}
		else if (key.equals("Login"))
		{
			o.clickOnLoginButton(driver);
			Thread.sleep(4000);
		}
		
		else if (key.equals("Logout"))
		{
			o.clickOnLogoutButton(driver);
			Thread.sleep(3000);
		}
	}
	
			System.out.println("valid Credential.");
			s.getRow(i).createCell(2).setCellValue("valid Credential.");

		}
		catch (Exception e)
		{

			System.out.println("Invalid Credential.");
			s.getRow(i).createCell(2).setCellValue("Invalid Credential.");
		}


}

	FileOutputStream out = new FileOutputStream("./ParaBank_DataDriven.xlsx");
	w.write(out);

	driver.close();
	w.close();

}
}
